# mongo20 cookbook

# Requirements

# Usage

# Attributes

# Recipes

# Author

Author:: Sascha Bates (<YOUR_EMAIL>)
