override[:mongodb][:package_name] = "mongodb20-10gen"
