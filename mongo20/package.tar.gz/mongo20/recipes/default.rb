#
# Cookbook Name:: mongo20
# Recipe:: default
#
# Copyright (C) 2013 Sascha Bates
# 
# All rights reserved - Do Not Redistribute
#

include_recipe "mongodb::10gen_repo"
include_recipe "mongodb"
